
<?php
?>

<!doctype html>
<title>Site Maintenance</title>
<style>
  body { text-align: center; }
  h1 { font-size: 50px; }
  body { font: 20px Helvetica, sans-serif; color: #0078dc; }
  article { display: block; text-align: left; width: 95%; margin: 0 auto; margin-top:250px!important;}
  a { color: #0078dc; text-decoration: none; }
  a:hover { color: #4a70fb; text-decoration: none; }
</style>

<article>
    <center><h1>We&rsquo;ll be back soon!</h1>



    <p>The Stallios Team</p></center>

</article>
